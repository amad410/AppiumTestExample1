package tests;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.remote.MobileCapabilityType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import java.net.URL;

public class BaseTest {

   //WebDriver _driver;
    //drivers more specific to appium testing
    static AppiumDriver _driver;
    //drivers more specific for android testing
    //AndroidDriver _androidDriver;
    //drivers more specific for IOS testing
    //IOSDriver _iOSDriver;

    @BeforeTest
    public void setup(){

        try {


            DesiredCapabilities caps = new DesiredCapabilities();
            //just an example of setting the capabilities of a device
            caps.setCapability(MobileCapabilityType.DEVICE_NAME, "Google Pixel");
            caps.setCapability(MobileCapabilityType.UDID, "89KY07YT6");
            caps.setCapability(CapabilityType.PLATFORM_NAME, "ANDROID");
            //caps.setCapability(MobileCapabilityType.PLATFORM_NAME, "ANDROID");
            caps.setCapability(MobileCapabilityType.VERSION, "10");
            caps.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, 60);

            //location of a physical Apk (android), ip, or app (iOS) stored in the solution
            //aps.setCapability(MobileCapabilityType.APP, "");

            //for launching chrome browser
            // caps.setCapability(MobileCapabilityType.BROWSER_NAME ,"Chrome");


            //set capability for the application package and activity. You can use Apk.info installed on the device or
            //or emulator to get this info
            caps.setCapability("appPackage", "com.google.android.calculator");
            caps.setCapability("appActivity", "com.android.calculator2.Calculator");

            //Pass url of Appium server and port
            URL serverurl = new URL("http://0.0.0.0:4723/wd/hub");
            //send these desired capabilities to the appium server
            _driver = new AppiumDriver<MobileElement>(serverurl, caps);
            //_driver = new AndroidDriver<MobileElement>(serverurl, caps);
           // _driver = new IOSDriver<MobileElement>(serverurl, caps);
        }
        catch(Exception ex){
            System.out.println("cause is: " + ex.getCause());
            System.out.println("Message is: " + ex.getMessage());
            ex.printStackTrace();
        }

    }

    @AfterTest
    public void teardown(){
        _driver.quit();

    }
}
