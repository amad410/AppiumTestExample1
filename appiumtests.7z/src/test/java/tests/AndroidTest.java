package tests;

import org.testng.annotations.Test;

public class AndroidTest extends BaseTest{

    @Test
    public void QuickTest(){
        System.out.println("Application Started");
    }
}
