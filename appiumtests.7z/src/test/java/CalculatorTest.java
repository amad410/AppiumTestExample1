import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.net.MalformedURLException;
import java.net.URL;

public class CalculatorTest {
    /*
    different types of driver options.
     */


    WebDriver _driver;
    //drivers more specific to appium testing
    static AppiumDriver _appiumDriver;
    //drivers more specific for android testing
    //AndroidDriver _androidDriver;
    //drivers more specific for IOS testing
    //IOSDriver _iOSDriver;
    public static void main(String args[])  {

        try {
            OpenCalculator();
        }
        catch (Exception ex) {
            System.out.println(ex.getMessage());
            ex.printStackTrace();
        }


    }

    public static void OpenCalculator() throws Exception {
        DesiredCapabilities caps = new DesiredCapabilities();
        //just an example of setting the capabilities of a device
        caps.setCapability("deviceName", "Google Pixel");
        caps.setCapability("udid", "89KY07YT6");
        caps.setCapability("platformName", "Android");
        caps.setCapability("platformVersion", "10");

        //set capability for the application package and activity. You can use Apk.info installed on the device or
        //or emulator to get this info
        caps.setCapability("appPackage", "com.google.android.calculator");
        caps.setCapability("appActivity", "com.android.calculator2.Calculator");

        //Pass url of Appium server and port
        URL serverurl = new URL("http://0.0.0.0:4723/wd/hub");
        //send these desired capabilities to the appium server
        _appiumDriver = new AppiumDriver<MobileElement>(serverurl,caps);
        System.out.println("Application Started");

        MobileElement one = (MobileElement) _appiumDriver.findElement(By.id(""));
        one.click();

        }
    }


